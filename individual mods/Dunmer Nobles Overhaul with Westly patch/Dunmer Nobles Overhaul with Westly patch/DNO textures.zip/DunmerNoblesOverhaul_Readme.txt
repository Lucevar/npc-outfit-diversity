The Elder Scrolls III MORROWIND:

==================
Dunmer Nobles Overhaul
==================
By Aoimevelho

17.02.2016

1. Description
2. Requirements
3. Installing the plug-in
4. Playing the plug-in
5. Save games
6. Conflicts/Known Errors
7. Credits/Permissions received
8. Contact and Information
9. Legal Stuff/Disclaimer
10. Anything else

===============
1. DESCRIPTION
===============
This mod adds 100 new hairstyles for Dunmer noblewomen (16 for Hlaalu, Redoran, Telvanni and Indoril, 17 for Dres and 19 for noblewomen not belonging to any House) and 29 new robes (4 for each House except Dres, 5 for Dres, 4 for Vvardenfell and 4 for the Mainland). Hairstyles are for MacKom's heads.

ALL noblewomen and SOME noblemen in original MW and in Tamriel Rebuilt are now wearing new robes as well as various shiny, expensive looking things: new hairstyles, veils and earrings for women, circlets, scarves and piercing for men.  By "noblemen" and "noblewomen" I literally mean NPCs who have class "Noble" assigned to them in CS. Some other high-ranking House members are also modified in House Telvanni which has a lot of NPCs with class "Wizard" but almost no NPCs with class "Noble". So I considered Telvanni wizards to be the equivalent of nobles in other Houses. 
 
I've also made an addon which adds random nobles to some appropriate locations (only indoors - to avoid fps hit) - just as an eye-candy and to showcase new items. Spawn points are set in Vivec cantons, Vivec Temple, Ebonheart keep, Hlaalu, Redoran, Telvanni council houses, Mournhold Temple and Godsreach. 

Hairstyles are also made into wigs. All new stuff is added to leveled lists so you have a chance to stumble upon it in game. (just don't forget to use a levelled list merging utility!)



Hlaalu items can be bought from Balmora Pawnbroker, from Suran Pawnbroker, from the Pawnbroker in Hlaalu Canton in Vivec

Dres items can be bought from the Temple Outfitter in Necrom

Redoran items can be bought from Malpenix Blonia in Ald-Ruhn, from the Trader in the Redoran Canton in Vivec

Indoril items can be bought from the Trader in Gorne, from Mournhold Trader

Telvanni items can be bought from Pawnbroker in Port Telvannis, from the street bosmer Pawnbroker in Sadrith Mora, from Berwen in Tel Mora, from the Enchanter in the Telvanni Canton in Vivec, from the Llothanis Merchant

Mainland items can be bought from the Trader in Necrom

Vvardenfell items can be bought from Tervur Braven in Vivec

All goods are added by means of levelled lists, so that trader's inventory changes each 72 in-game hours. There is also a chance for random items to spawn.



If someone decides to add ears and thus make hairstyles compatible with older heads meshes - feel free to do so.


===============
2. Requirements
===============
MacKom's Dunmer Heads (and hairstyles adapted for them.)
TR Heads Replacer (MacKom's heads) - for Tamriel Rebuilt users
Any leveled lists merging utility

The Great Houses robes have reflection mapped details so in order for them to be displayed correctly you need Morrowind Code Patch. 

========================
3. INSTALLING THE PLUGIN
========================
Copy /Meshes and /Textures folders to Morrowind/Data files.

=====================
4. PLAYING THE PLUGIN
=====================
Use only one of these files - don't use both:
DunmerNoblesOverhaul.ESP -  if you don't have Tamriel Rebuilt installed
DunmerNoblesOverhaul_TR.ESP - if you have Tamriel Rebuilt

DNO_RandomNoblesAddon.ESP - adds random nobles to some indoor locations on Vvardenfell
DNO_RandomNoblesAddon_TR.ESP - adds random nobles to some indoor locations on Vvardenfell and the Mainland but use it if you have TR installed (the difference - this one has TR heads assigned to the generated nobles.) 

Optional files DNO_Hairstyles.ESP and DNO_Robes&Scarves.ESP contain only hairstyles and robes&scarves respectively. YOU DON'T NEED THEM TO PLAY THIS PLUGIN. 


===============
5. SAVE GAMES
===============

============================
6. CONFLICTS / KNOWN ERRORS
============================

WARNING: if you have already seen a NPC during the current playthrough, the game "remembers" their clothes, so, when modified by a mod, only their hairstyle and face will change. In order to see changes to NPCs equipment you should either delete the info about particular NPCs from your save file (e.g. by TESAME or Enchanted Editor or other similar utility), or start a new playthrough.

================================
7. CREDITS / PERMISSIONS RECEIVED
================================
Kafeid - circlets and piercing 
Kagz - flowers
Xanondorf - some robes textures (modified by me)
NioLiv - veils models and textures
Niero - face scarf model
Moranar - robes model (modified by me)
Melian - comb model
Rhedd  - hair parts
idkrrr - hair parts (braided hair "knots" on "generic" noble women hairstyles) 
TR team - textures with Indoril and Dres symbols I used for Indoril and Dres robes
Chests - free resource by Runspect
Reflection maps - Phijama

(I hope I didn't forget anyone.)

==========================
8. CONTACT AND INFORMATION
==========================
You may find me as Aoimevelho on http://forums.bethsoft.com or as ivolga on nexus.

=========================
9. LEGAL STUFF/ DISCLAIMER
=========================
You can use everything I created for this mod in your own projects. Just don't charge money for it and don't forget about credits.

=================
10. ANYTHING ELSE
=================
:) Have fun!