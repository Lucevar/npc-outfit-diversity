The Elder Scrolls III MORROWIND:

==================
ArmoredRobes_NPC_Compilation
==================
By Aoimevelho

10.02.2016

1. Description
2. Requirements
3. Installing the plug-in
4. Playing the plug-in
5. Save games
6. Conflicts/Known Errors
7. Credits/Permissions received
8. Contact and Information
9. Legal Stuff/Disclaimer
10. Anything else


===============
1. DESCRIPTION
===============
This is a compilation of my Armored Robes mods: Original Armored Robes + Mabrigash Armored Robes + Indoril Armored Robes. It adds the new armors to many NPCs in game, adds some robes to traders' stock and adds them to leveled lists.


===============
2. Requirements
===============


========================
3. INSTALLING THE PLUGIN
========================
Copy all files into Morrowind/Data files folder. 


=====================
4. PLAYING THE PLUGIN
=====================

===============
5. SAVE GAMES
===============

============================
6. CONFLICTS / KNOWN ERRORS
============================

================================
7. CREDITS / PERMISSIONS RECEIVED
================================
Original robes and cuirasses meshes - Moranar
Icons - WH-Reaper
Hood - Atrius
Face mask mesh - Calder Ross / Niero
Skirt texture - by N'Dib
Ordinator Helmet - by JB

==========================
8. CONTACT AND INFORMATION
==========================
You may find me as Aoimevelho on http://forums.bethsoft.com or as ivolga on nexus.

=========================
9. LEGAL STUFF/ DISCLAIMER
=========================
You can do with this mod whatever you want, just don't make money out of it and don't forget about credits. No need to ask additional permission.

=================
10. ANYTHING ELSE
=================
:) Have fun!